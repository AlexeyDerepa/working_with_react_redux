import React from 'react';
import ReactDOM from "react-dom";

ReactDOM.render(
  <h2>Здесь может быть любой текст</h2>, 
  document.getElementById('fieldToShow')
);
